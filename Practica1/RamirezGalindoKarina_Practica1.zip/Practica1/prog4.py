cadena1=input('Ingresa una cadena:')
car=cadena1[:1]
cadena2 = cadena1.replace(car,'$')
print(cadena2)