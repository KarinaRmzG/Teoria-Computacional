w='b,c,a,2,1,3'
palabras=w.split(',')
print (f"Las palabras originales son: \n {palabras}")


palabras.sort()
print (f"Las palabras ordenadas son: \n {palabras}")