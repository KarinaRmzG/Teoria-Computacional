num=input("Ingrese un numero: ")
a=input("Ingrese el ancho: ")

num=num.zfill(int(a))
print(f"el numero es: {num}")