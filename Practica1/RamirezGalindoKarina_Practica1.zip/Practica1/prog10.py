cadena1=input("Escribe una cadena: ")
palabra=input("Escribe una palabra que este dentro de la cadena: ")
print("Concurrencias-> "+str(cadena1.count(palabra)))