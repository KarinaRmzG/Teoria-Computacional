cadena1=input("Escriba una cadena: ")
print(f"La cadena es: {sorted(cadena1)}")