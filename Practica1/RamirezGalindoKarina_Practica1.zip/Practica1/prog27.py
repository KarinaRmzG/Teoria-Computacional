numero=int(input("Escriba un numero: "))
print(format(numero, ','))
