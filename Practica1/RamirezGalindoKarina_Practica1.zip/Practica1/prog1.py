cadena=input("Escriba una cadena: ")
caracteres=len(cadena)
print(f"la cadena tiene {caracteres} caracteres")