num=float(input("Ingrese un numero: "))
if num<0:
    print(f"el numero es: {'%.2f'%num}")
else:
    print(f"el numero es: +{'%.2f' % num}")