num=float(input("Ingrese un numero: "))
print(f"el numero es: {'%.2f'%num}")