n1=int(input("Escribe el valor R:"))
n2=int(input("Escribe el valor G:"))
n3=int(input("Escribe el valor B:"))

print("La cadena es: #{:02x}{:02x}{:02x}".format(n1,n2,n3))