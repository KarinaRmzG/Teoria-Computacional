
num= input("Escribe un numero entero: ")
a=int(input("Esbribe el ancho: "))
print("{:*<{}}".format(num,a))