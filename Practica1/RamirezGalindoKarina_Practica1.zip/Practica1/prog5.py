w='abc'
v='xyz'
result=v[:2] + w[2:] + " " + w[:2] + v[2:]
print (f"Las nuevas cadenas son: \n {result}")